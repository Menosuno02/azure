﻿namespace MvcCoreApiClient.Models
{
    public class Hospital
    {
        public int IdHospital { get; set; }
    }
}
